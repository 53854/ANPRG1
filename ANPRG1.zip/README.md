# ANPRG1
Project for the applied programming course in HAW-Hamburg

Made with open trivia database: https://opentdb.com/
