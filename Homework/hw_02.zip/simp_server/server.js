const express = require('express');
const app = express();

app.use(express.static(__dirname + '/public'));


app.get("/index", function (req, res){
    res.sendFile(__dirname + '/public/index.html');
});

app.get("/login", function (req, res){
    res.sendFile(__dirname + '/public/login.html');
});

app.listen(3000, function (){
    console.log("Simps are donating on port 3000");
});
