const express = require("express");
const app = express();

const bodyParser = require("body-parser");
const e = require("express");
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(__dirname + "/views"));
app.engine(".ejs", require("ejs").__express);
app.set("view engine", "ejs");

app.get(["/", "/index"], function (req, res) {
  res.render("index");
});

app.post("/login", function (req, res) {

  var username = req.body.un;
  var password = req.body.pw;

  var succ = "Login failed";

  if (anmeldungErfolgreich(username, password)) {
    succ = "Login successful<br/>welcome " + username;
  }

  res.render("login", { welcome: succ });
});

app.listen(3000, function () {
  console.log("Simps are donating on port 3000");
});

var benutzer = [
  {
    name: "Alice",
    passwort: "§$Y45/912v",
  },
  {
    name: "Bob",
    passwort: "secret",
  },
  {
    name: "Carla",
    passwort: "123",
  },
  {
    name: "David",
    passwort: "divaD",
  },
];

function anmeldungErfolgreich(benutzername, passwort) {
  for (var i = 0; i < benutzer.length; i++) {
    if (
      benutzername === benutzer[i].name &&
      passwort === benutzer[i].passwort
    ) {
      return true;
    }
  }
  return false;
}
